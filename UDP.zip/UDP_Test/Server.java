import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Collections;
import java.awt.BorderLayout;

import javax.swing.*;
public class Server extends JFrame {

	private JTextArea displayArea;//display packets
	
	private DatagramSocket socket; //socket to connect
	
	
	
	//byte[] array = new byte[17];
	
	public Server()
	{
		super( "Server" );
		
		displayArea = new JTextArea();
		add( new JScrollPane( displayArea ), BorderLayout.CENTER);
		setSize(400, 300); // set size
		setVisible(true); //show window
		
		
		
		try//attempt to create DatagramSocket
		{
			socket = new DatagramSocket( 5000 );
		}
		catch(SocketException socketException)
		{
			socketException.printStackTrace();
			System.exit(1);
			
		}//end catch
	}//end server constructor
	
	//wait for packets to show up
	public void waitForPackets()
	{
		while( true )
		{
			try // receive packets
			{
				byte[] data = new byte[ 100 ]; //set packet up
				DatagramPacket receivePacket = new DatagramPacket (data, data.length);
				
				socket.receive( receivePacket );//wait to get packet
				
			
				
				sendPacketToClient(receivePacket);
			}
			catch (IOException ioException)
			{
				displayMessage (ioException + "\n");
				ioException.printStackTrace();
			}//end catch
		}//end while
		
	}//end method waitForPackets

	//echo packet to client
	private void sendPacketToClient(DatagramPacket receivePacket) throws IOException {
		/*
		int count = 0;
		byte[] array = new byte[17];
		ArrayList<Integer> ShuffledDeck = new ArrayList<Integer>();
		
		for(int i = 0; i <= 16; i++) {
			ShuffledDeck.add(i);
		}
		Collections.shuffle(ShuffledDeck);
		
		count = 0;
		while( count != ShuffledDeck.size()){
		 array[count] = ShuffledDeck.get(count).byteValue();
		 count++;
		}
		
		
		//create packet to send
		DatagramPacket sendPacket = new DatagramPacket(
				array, array.length,
				receivePacket.getAddress(), receivePacket.getPort());
		
		socket.send(sendPacket);//send to client
		displayMessage("Packet sent\n");
		*/
		
		byte[] cardsPlayed = new byte[3];
		byte[] x = new byte[2];
		cardsPlayed[0] = 9;
		x = receivePacket.getData();
		cardsPlayed[1] = x[0];
		
		System.out.println("received cards: " + cardsPlayed[0] + " " + cardsPlayed[1]);
		
		//create packet to send
				DatagramPacket sendPacket = new DatagramPacket(
						cardsPlayed, cardsPlayed.length,
						receivePacket.getAddress(), receivePacket.getPort());
				
				socket.send(sendPacket);//send to client
		
		
		
	}//end sendPacketToClient
	
	private void displayMessage(final String messageToDisplay)
	{
		SwingUtilities.invokeLater(
				new Runnable()
				{
					public void run() //updates displayArea
					{
						displayArea.append(messageToDisplay);//display message
					}//end method run
				}//end anonymous innerclass
				);//end call to SwingUtilities.invokeLater
	}//end method displayMessage
	
	
}//end class server
