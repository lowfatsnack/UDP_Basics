import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
public class Client extends JFrame {

	private JTextField enterField; // enter message
	private JTextArea displayArea; // display message
	private DatagramSocket socket; //socket to connect to server
	private byte[] data = new byte[1];
	
	//public Integer array
	
	public Client()
	{
		super("Client");
		
		enterField = new JTextField("Type message here");
		enterField.addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent event)
					{
						try //create and send
						{
							//get message
							String message = event.getActionCommand();
							displayArea.append("\nSending packet containing: " + message + "\n");
							
							Integer x = 10;
							data[0] = x.byteValue(); // converts to bytes
							
							DatagramPacket sendPacket = new DatagramPacket(data, data.length, InetAddress.getLocalHost(), 5000);
							
							socket.send(sendPacket);//send packet
							displayArea.append("Packet sent\n");
							displayArea.setCaretPosition(
									displayArea.getText().length());
						}//end try
						catch (IOException ioException )
						{
							displayMessage (ioException + "\n");
							ioException.printStackTrace();
						}//end catch
					}//end ActionPerformed
				}//end inner class
				);//end call to addActionListener
		
				add( enterField, BorderLayout.NORTH);
				
				displayArea = new JTextArea();
				add( new JScrollPane(displayArea ), BorderLayout.CENTER);
				
				setSize(400, 300); //set windowsize
				setVisible(true); //show window
				
				try //create DatagramSocket
				{
					socket = new DatagramSocket();
				}//end try
				catch(SocketException socketException)
				{
					socketException.printStackTrace();
					System.exit(1);
				}//end catch
	}//end of constructor
	
	public void waitForPackets()
	{
		while(true)
		{
			try // get packet and display
			{
				byte[] data = new byte[100]; //set packet up
				
				DatagramPacket receivePacket = new DatagramPacket(
						data, data.length);
				socket.receive(receivePacket); // wait for packet
				
				
				int[] x = new int[52];
				byte[] y = new byte[200];
				y = receivePacket.getData();
				
				;
				//display packet content
				for(int i = 0; i < receivePacket.getLength();i++){
					System.out.println(y[i]);
				}
				
				
				
			//	System.out.println(fromByteArray(y));
			}//end try
			catch(IOException exception)
			{
				displayMessage(exception + "\n");
				exception.printStackTrace();
			}//end catch
		}//end while
	}//end wait for packets

	private void displayMessage(final String messageToDisplay) {
		SwingUtilities.invokeLater(
				new Runnable()
				{
					public void run()//updates display
					{
						displayArea.append(messageToDisplay);
					}//end run
				}//end inner class
				);//end invokeLater
		
	}//end displayMessage
	
	public static int[] toIntArray(byte buf[]) 
	{
	    final ByteBuffer buffer = ByteBuffer.wrap(buf)
	        .order(ByteOrder.LITTLE_ENDIAN);
	    final int[] ret = new int[buf.length / 4];
	    buffer.asIntBuffer().put(ret);
	    return ret;
	}
	static int fromByteArray(byte[] bytes) {
	     return ByteBuffer.wrap(bytes).getInt();
	}
	
	
}//end of Client
