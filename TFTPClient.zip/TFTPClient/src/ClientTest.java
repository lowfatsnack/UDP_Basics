import java.io.IOException;

public class ClientTest {

	public static void main(String[] args) throws InterruptedException, IOException {
		Client client = new Client();
		client.sendRRQ();
	}

}
