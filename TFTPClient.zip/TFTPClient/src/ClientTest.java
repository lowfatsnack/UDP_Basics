
public class ClientTest {

	public static void main(String[] args) throws InterruptedException {
		Client client = new Client();

		client.sendRRQ();
	}

}
