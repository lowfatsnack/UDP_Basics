import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;

public class Client {
	private DatagramSocket socket;
	private DatagramPacket sendPacket;// sends packet to server
	private DatagramPacket incoming;
	private static byte[] data = new byte[516];// information that is sent through to the server
	private byte[] incData = new byte[512]; // set packet up, from incoming data
	private static int bNum = 0;
	private int expectedBNum = 0; // should always be one ahead except for the start
	private byte[] request;
	private static String fName = "placeholder.txt";// name of file to be read/written
	private String mode = "octet";// default mode is set to octet
	private boolean received = false;
	private boolean terminate = false;

	static File file = new File(fName);
	FileInputStream fStream = null;

	private InetAddress inetAddress = null;
	private boolean ackGet = false;

	private int serverPort = 69;
	private int clientPort = 0;// pick a number
	private static int errorCode;

	// Opcodes
	static final byte opRRQ = 1;
	static final byte opWRQ = 2;
	static final byte opDATA = 3;
	static final byte opACK = 4;
	static final byte opERROR = 5;

	// timeout variable
	private final static int timeout = 3000; // use socket.setSOTimeout(timeout)
	private final static int waitTime = 500;
	private static int tries = 10;

	public Client() {

		try // create DatagramSocket
		{
			socket = new DatagramSocket();

		} // end try
		catch (SocketException socketException) {
			socketException.printStackTrace();
			System.exit(1);
		} // end catch
	}

	// sends the initial read request to the server
	public void sendRRQ() throws InterruptedException {
		try {
			inetAddress = InetAddress.getLocalHost(); // gets the server
			byte[] read = ReadPacket(fName, mode);
			DatagramPacket packet = new DatagramPacket(read, read.length, inetAddress, serverPort);
			socket.setSoTimeout(timeout);
			send(); // are we sending the packet variable, would this be sendRequest Method
			Receive(); // are we receiving the file?

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void sendWRQ() throws InterruptedException {
		int j = 0;
		int k = 0;
		int i = 2;
		

		byte[] fileBytes = stringToByte(fName);
		byte[] modeBytes = stringToByte(mode);

		int length = 4 + fileBytes.length + modeBytes.length;
		
		byte[] blockNum = getByteArray(bNum);
		
		request = new byte[length];
		
		request[0] = 0;
		request[1] = 2;
		// sets a request packet up with the required amount of space
		

		while (i < request.length) {
			// fills data[] up until end of string, including the termination byte
			if (j < fileBytes.length) {

				request[i] = fileBytes[j];
				j++;
				i++;

			}
			// if fileName is filled do this
			else {
				request[i] = 0; // byte that takes the place after filename and mode
								// fills to end of packet
				i++;

				while (k < modeBytes.length) {
					request[i] = modeBytes[k];

					k++;
					i++;
				} // end of while
				

			} // end of else
		} // end of while request loop

		try {
			sendRequest(request);
			receiveAck(blockNum);
			sendDATA();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // end of catch

	}// end of method

	// get packets for read request
	public void Receive() throws IOException, InterruptedException {
		int count = 0;
		// used to check the incoming block number
		byte[] blockNum = getByteArray(expectedBNum);

		incoming = new DatagramPacket(data, data.length);
		socket.setSoTimeout(timeout);
		while (received != true && count < tries) {
			try {
				socket.receive(incoming); // wait for packet

				received = true;
			} catch (IOException e) {
				Thread.sleep(3000);
				send();
				count++;
			}
		} // end of count while
		received = false;

		incData = incoming.getData();

		if (incData[2] == blockNum[0] && incData[3] == blockNum[1]) {
			// do nothing
		} else {
			// call the send ack method and send the expected block number to the server
		}
	}// end of receive

	public void send() throws UnknownHostException {

		byte[] blockNum = getByteArray(bNum);
		data[2] = blockNum[0];
		data[3] = blockNum[1];
		// placeholder packet to send
		sendPacket = new DatagramPacket(data, data.length, InetAddress.getLocalHost(), serverPort);

		try {
			socket.send(sendPacket);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}// end of send

	////////////////////////////////// Send Packet Methods
	////////////////////////////////// //////////////////////////////
	public void sendDATA() throws IOException, InterruptedException {
		fStream = new FileInputStream(file);
		byte[] blockNum = getByteArray(bNum);
		// use a file input stream and fill the bytes of the packet with data from the
		// file
		int i = 4;
		int fileInt = 0;
		data[0] = 0;
		data[1] = 3;
		data[2] = blockNum[0];
		data[3] = blockNum[1];

		if (mode.contains("octet")) {
			while ((fileInt = fStream.read()) != -1) {

				data[i] = (byte) (fileInt & 0xff);
				i++;
				if (i == 516) {
					send();
					receiveAck(blockNum);
					blockNum = getByteArray(bNum);
					data[2] = blockNum[0];
					data[3] = blockNum[1];

					i = 4;

				} // end of full packet

			} // end of while
			
			data[i] = (byte) (fileInt & 0xff);
			byte[] fPack = new byte[i];
			i = 0;
			while(i < fPack.length) {
				fPack[i] = data[i];
				i++;
			} //fills last packet
			sendPacket = new DatagramPacket(fPack, fPack.length, InetAddress.getLocalHost(), serverPort);
			socket.send(sendPacket);
			receiveAck(blockNum);
			
			
			
		} // end of check of octect mode

		else {

		} // end of netascii mode

	}// end of method

	public void sendError() throws IOException {
		byte[] error = ErrorPacket(errorCode);
		DatagramPacket packet = new DatagramPacket(error, error.length, InetAddress.getLocalHost(),
				serverPort);
		try {
			socket.send(packet);

		} catch (IOException e) {
			e.printStackTrace();
		}

	}// end of method

	private void sendAck() throws IOException {
		byte[] ACK = AckPacket(bNum);

		// Gets new port and sends the ack
		DatagramPacket ack = new DatagramPacket(ACK, ACK.length, serverPort);

		try {
			socket.send(ack);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}// end of sendAck

	////////////////////////////////// Conversion Methods
	////////////////////////////////// //////////////////////////////
	/*
	 * Converts an int to a byte array of size 2
	 */
	public static byte[] getByteArray(int integer) {
		byte[] array = new byte[2];
		array[1] = (byte) (integer & 0xFF);
		array[0] = (byte) ((integer >> 8) & 0xFF);
		return array;
	}

	/*
	 * If we have a method for int to byte, might as well have byte to int
	 */
	public static int getInt(byte[] array) {
		int integer;
		integer = ((array[0] & 0xff) << 8) | (array[1] & 0xff);
		return integer;
	}

	// gets a string and converts to a byte array
	public byte[] stringToByte(String chara) {
		
		byte[] conversion = chara.getBytes(StandardCharsets.US_ASCII);

		return conversion;

	}// end do of stringToByte

	public void sendRequest(byte[] a) throws IOException {

		sendPacket = new DatagramPacket(a, a.length, InetAddress.getLocalHost(), serverPort);
		socket.send(sendPacket);
	}

	/////////////////////////// Methods We Don't Use But Could Find Useful
	/////////////////////////// //////////////////////////////
	private boolean isLastPacket(DatagramPacket datagramPacket) {
		if (datagramPacket.getLength() < 512)
			return true;
		else
			return false;
	}// end of isLastPacket

	private byte[] incrementBNum(byte[] blocknumber) {
		if (blocknumber[1] == -1) {
			blocknumber[0]++;
		}
		blocknumber[1]++;
		return blocknumber;
	}

	private byte[] putDataIntoByteArray(FileInputStream fis, File file) {
		byte[] a = new byte[Math.min(512, (int) file.length())];
		System.out.println("Length of data array: " + a.length);
		try {
			fis.read(a, 0, Math.min(512, (int) file.length()));
		} catch (IOException e) {
			System.out.println("error: " + e.getMessage());
		}
		return a;
	}

	////////////////////////////////// PACKETS //////////////////////////////
	public static byte[] ErrorPacket(int errorCode) throws IOException {
		ByteArrayOutputStream outputPacket = new ByteArrayOutputStream();

		String errorMessage = null;

		switch (errorCode) {
		case 0:
			errorMessage = "Undefined";
			break;
		case 1:
			errorMessage = "File not found";
			break;
		case 2:
			errorMessage = "Access Violation.";
			break;
		case 3:
			errorMessage = "Disk full or allocation exceeded.";
			break;
		case 4:
			errorMessage = "Bad TFTP operation.";
			break;
		case 5:
			errorMessage = "Unknown transfer ID";
			break;
		case 6:
			errorMessage = "File already exists.";
			break;
		case 7:
			errorMessage = "Not a user.";
			break;
		}

		outputPacket.write(opERROR);
		outputPacket.write(getByteArray(errorCode));
		outputPacket.write(errorMessage.getBytes());
		outputPacket.write(opERROR);
		outputPacket.write((byte) 0);

		return outputPacket.toByteArray();
	}

	public static byte[] AckPacket(int block) throws IOException {
		ByteArrayOutputStream outputPacket = new ByteArrayOutputStream();

		outputPacket.write(opACK);
		outputPacket.write(getByteArray(block));

		return outputPacket.toByteArray();
	}

	public static byte[] ReadPacket(String filename, String mode) throws IOException {
		ByteArrayOutputStream outputPacket = new ByteArrayOutputStream();

		outputPacket.write(opRRQ);
		outputPacket.write(filename.getBytes());
		outputPacket.write((byte) 0);
		outputPacket.write(mode.getBytes());
		outputPacket.write((byte) 0);

		return outputPacket.toByteArray();
	}

	public static byte[] WritePacket(String filename, String mode) throws IOException {
		ByteArrayOutputStream outputPacket = new ByteArrayOutputStream();

		outputPacket.write(opWRQ);
		outputPacket.write(filename.getBytes());
		outputPacket.write((byte) 0);
		outputPacket.write(mode.getBytes());
		outputPacket.write((byte) 0);

		return outputPacket.toByteArray();

	}

	public static byte[] DataPacket(int block, byte[] data) throws IOException {
		ByteArrayOutputStream outputPacket = new ByteArrayOutputStream();

		outputPacket.write(opDATA);
		outputPacket.write(getByteArray(bNum));
		outputPacket.write(data);

		return outputPacket.toByteArray();

	}

	public void receiveAck(byte[] block) throws InterruptedException, UnknownHostException, SocketException {
		byte[] ack = new byte[4];
		incoming = new DatagramPacket(ack, ack.length);

		socket.setSoTimeout(timeout);
		while (!received && tries > 0) {
			try {
				socket.receive(incoming);

				byte[] obtained = incoming.getData();
				if (block[0] == obtained[2] && block[1] == obtained[3]) {
					tries = 10;
					serverPort = incoming.getPort();
					bNum++;
					break;
				}
				else {
					tries--;
					send();
				}//end of incorrect packet check
			} catch (IOException e) {

				e.printStackTrace();

			}//end of catch
		} // end of while not received or count = 10
		if (tries == 0)
			terminate = true;

	}

}
