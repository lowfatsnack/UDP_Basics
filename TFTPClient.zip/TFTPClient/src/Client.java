import java.net.DatagramSocket;
import java.net.SocketException;

import javax.swing.JFrame;

public class Client extends JFrame 
{
	private DatagramSocket socket;
	private byte[] data = new byte[1];
	
	public Client() {
		super("Client");
		
		try //create DatagramSocket
		{
			socket = new DatagramSocket();
		}//end try
		catch(SocketException socketException)
		{
			socketException.printStackTrace();
			System.exit(1);
		}//end catch
	}
	
	public void sendRRQ() 
	{
		
		
	}
	
	public void sendWRQ() 
	{
		
	}
	
	public void sendDATA() 
	{
		
	}
	
	public void sendError() 
	{
		
	}
	
	public void receive()
	{
		
	}
	
	
	
}
