import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

public class Client {
	private DatagramSocket socket = null;
	private DatagramPacket sendPacket;// sends packet to server
	private DatagramPacket incoming;
	private byte[] data = new byte[512];// information that is sent through to the server
	private byte[] incData = new byte[512]; // set packet up, from incoming data
	private int bNum = 0;
	private int expectedBNum = 0; // should always be one ahead except for the start
	private byte[] bufferByteArray;
	private byte[] request;
	private String fName = "placeholder.txt";// name of file to be read/written
	private String mode = "octet";// default mode is set to octet
	private boolean received = false;
	

	File file = new File(fName);
	FileInputStream fStream = null;

	private InetAddress inetAddress = null;
	private boolean ackGet = false;

	private int serverPort = 69;
	private int clientPort = 0;// pick a number
	private static int errorCode;

	// Opcodes
	static final byte opRRQ = 1;
	static final byte opWRQ = 2;
	static final byte opDATA = 3;
	static final byte opACK = 4;
	static final byte opERROR = 5;

	// timeout variable
	private final static int timeout = 3000; // use socket.setSOTimeout(timeout)

	public Client() {

		try // create DatagramSocket
		{
			socket = new DatagramSocket();

		} // end try
		catch (SocketException socketException) {
			socketException.printStackTrace();
			System.exit(1);
		} // end catch
	}

	public void sendRRQ() throws InterruptedException {
		int j = 0;
		int k = 0;
		data[0] = 0;
		data[1] = 1;

		byte[] fileBytes = stringToByte(fName);
		byte[] modeBytes = stringToByte(mode);

		for (int i = 2; i < data.length; i++) {
			// fills data[] up until end of string, including the termination byte
			if (j < fName.length() + 1) {

				data[i] = fileBytes[j];
				j++;

			}
			// if fileName is filled do this
			else {
				data[i] = 0; // byte that takes the place after filename and mode
								// fills to end of packet

				while (k < mode.length()) {
					data[i] = modeBytes[k];

					k++;
					i++;
				} // end of while

			} // end of else

		} // end of for loop

		try {
			send();
			Receive();

			// checks the ack for the correct code and block number
			if (incData[1] == 4 && incData[3] == 0) {

				serverPort = incoming.getPort(); // updates the serverPort the the new #;
				// sendDATA
			}

			else {

			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // end of catch

	}

	public void sendWRQ() throws InterruptedException {
		int j = 0;
		int k = 0;
		int i = 2;
		request[0] = 0;
		request[1] = 2;
	

		byte[] fileBytes = stringToByte(fName);
		byte[] modeBytes = stringToByte(mode);
		
		//sets a request packet up with the required amount of space
		int length = 4 + fName.length() + mode.length();
		request = new byte[length];

		while(i < request.length) {
			// fills data[] up until end of string, including the termination byte
			if (j < fName.length() + 1) {

				request[i] = fileBytes[j];
				j++;
				i++;

			}
			// if fileName is filled do this
			else {
				request[i] = 0; // byte that takes the place after filename and mode
								// fills to end of packet

				while (k < mode.length()) {
					request[i] = modeBytes[k];

					k++;
					i++;
				} // end of while
				request[i] = 0;
				
			} // end of else
		}//end of while request loop

		try {
			sendRequest(request);
			Receive();

			// checks the ack for the correct code and block number
			if (incData[1] == 4 && incData[3] == 0) {

				serverPort = incoming.getPort(); // updates the serverPort with the new #;
				// sendDATA
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // end of catch

	}// end of method

	public void sendDATA() throws IOException {
		fStream = new FileInputStream(file);
		// use a file input stream and fill the bytes of the packet with data from the
		// file
		int i = 4;
		int fileInt;
		data[0] = 0;
		data[1] = 3;
		
		if (mode.contains("octect")) {
			while ((fileInt = fStream.read()) != 1) {
				
			

			}

		} // end of check of octect mode

		else {

		} // end of netascii mode

	}// end of method

	public void sendError() throws IOException {
		byte[] error = ErrorPacket(errorCode);
		DatagramPacket packet = new DatagramPacket(error, error.length, InetAddress.getByName("199.17.161.177"),
				serverPort);
		try {
			socket.send(packet);

		} catch (IOException e) {
			e.printStackTrace();
		}

	}// end of method

	// gets a string and converts to a byte array
	public byte[] stringToByte(String chara) {
		char[] letters = chara.toCharArray();// creates an array of characters
		byte[] conversion = new byte[letters.length + 1];

		for (int i = 0; i < letters.length; i++) {
			if (i == letters.length) {
				conversion[i] = 0; // indicates end of file name
			}

			else {
				conversion[i] = (byte) letters[i]; // converts character into byte
			}

		} // end of for loop

		return conversion;

	}// end do of stringToByte

	private boolean isLastPacket(DatagramPacket datagramPacket) {
		if (datagramPacket.getLength() < 512)
			return true;
		else
			return false;
	}// end of isLastPacket

	private ByteArrayOutputStream receiveFile() throws IOException {
		ByteArrayOutputStream byteOutOS = new ByteArrayOutputStream();

		do {
			System.out.println("TFTP Packet Count: " + bNum);
			
			incoming = new DatagramPacket(data, data.length, inetAddress, serverPort);

			// receiving the packet from server
			socket.receive(incoming);

			// gets data from packet, first two bytes are opcode, bytes 3,4 are bNum
			byte[] obtainedPack = incoming.getData();

			if (obtainedPack[1] == opERROR) {
				reportError();
			} else if (obtainedPack[1] == opDATA) {

				DataOutputStream stream = new DataOutputStream(byteOutOS);
				stream.write(incoming.getData(), 4, incoming.getLength() - 4);

				sendAck();
			}

		} while (!isLastPacket(incoming));
		return byteOutOS;
	}// end of recieveFile

	private void reportError() {
		String errorCode = new String(data, 3, 1);
		String errorText = new String(data, 4, incoming.getLength() - 4);
		System.err.println("Error: " + errorCode + " " + errorText);
	}// end of reportError

	private void sendAck() {
		getByteArray(bNum);
		byte[] ACK = { 0, opACK, };

		// Gets new port and sends the ack
		DatagramPacket ack = new DatagramPacket(ACK, ACK.length, serverPort);

		try {
			socket.send(ack);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}// end of sendAck

	// get packets for read request
	public void Receive() throws IOException, InterruptedException {
		int count = 0;
		//used to check the incoming block number
		byte[] blockNum = getByteArray(expectedBNum);

		incoming = new DatagramPacket(data, data.length);
		socket.setSoTimeout(timeout);
		while (received || count < 10) {
			try {
				socket.receive(incoming); // wait for packet
				
				received = true;
			} catch (IOException e) {
				wait(500);
				send();
				count++;
			}
		} // end of count while
		received = false;

		incData = incoming.getData();
		
		if(incData[2] == blockNum[0] && incData[3] == blockNum[1] ) {
			//do nothing
		}
		else {
			//call the send ack method and send the expected block number to the server
		}
	}// end of receive

	public void send() throws UnknownHostException {
		
		byte[] blockNum = getByteArray(bNum);
		expectedBNum++;
		data[2] = blockNum[0];
		data[3] = blockNum[1];
		// placeholder packet to send
		sendPacket = new DatagramPacket(data, data.length, InetAddress.getByName("199.17.161.177"), serverPort);

		try {
			socket.send(sendPacket);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}// end of send

	public static byte[] ErrorPacket(int errorCode) throws IOException {
		ByteArrayOutputStream outputPacket = new ByteArrayOutputStream();

		String errorMessage = null;

		switch (errorCode) {
		case 0:
			errorMessage = "Undefined";
			break;
		case 1:
			errorMessage = "File not found";
			break;
		case 2:
			errorMessage = "Access Violation.";
			break;
		case 3:
			errorMessage = "Disk full or allocation exceeded.";
			break;
		case 4:
			errorMessage = "Bad TFTP operation.";
			break;
		case 5:
			errorMessage = "Unknown transfer ID";
			break;
		case 6:
			errorMessage = "File already exists.";
			break;
		case 7:
			errorMessage = "Not a user.";
			break;
		}

		outputPacket.write(opERROR);
		outputPacket.write(getByteArray(errorCode));
		outputPacket.write(errorMessage.getBytes());
		outputPacket.write(opERROR);
		outputPacket.write((byte) 0);

		return outputPacket.toByteArray();
	}

	/*
	 * Converts an int to a byte array of size 2
	 */
	public static byte[] getByteArray(int integer) {
		byte[] array = new byte[2];
		array[1] = (byte) (integer & 0xFF);
		array[0] = (byte) ((integer >> 8) & 0xFF);
		return array;
	}

	/*
	 * If we have a method for int to byte, might as well have byte to int
	 */
	public static int getInt(byte[] array) {
		int integer;
		integer = ((array[0] & 0xff) << 8) | (array[1] & 0xff);
		return integer;
	}

	public static byte[] AckPacket(int block) throws IOException {
		ByteArrayOutputStream outputPacket = new ByteArrayOutputStream();

		outputPacket.write(opACK);
		outputPacket.write(getByteArray(block));

		return outputPacket.toByteArray();
	}

	public void sendRequest(byte[] a) throws IOException {
		
		sendPacket =  new DatagramPacket(a, a.length, InetAddress.getByName("199.17.161.177"), serverPort);
		socket.send(sendPacket);
	}
}
