import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;

import javax.swing.JFrame;

public class Client extends JFrame 
{
	private DatagramSocket socket = null;
	private DatagramPacket sendPacket;//sends packet to server
	private DatagramPacket incoming;
	private byte[] data = new byte[512];//information that is sent through the packet
	private byte[] bNum = new byte[2];//block number
	private byte[] bufferByteArray;
	private String fName = "placeholder.txt";//name of file to be read/written
	private String mode = "octet";//default mode is set to octet
	
	private InetAddress inetAddress = null;
	
	private final int maxPacketSize = 512;
	private int initialPort = 69;
	
	//Opcodes
    static final byte RRQopcode[] = {(byte) 0, (byte) 1}; 
    static final byte WRQopcode[] = {(byte) 0, (byte) 2}; 
    static final byte DATAopcode[] = {(byte) 0, (byte) 3}; 
    static final byte ACKopcode[] = {(byte) 0, (byte) 4}; 
    static final byte ERRORopcode[] = {(byte) 0, (byte) 5};
    static final byte opRRQ = 1;
    static final byte opWRQ = 2;
    static final byte opDATA = 3;
    static final byte opACK = 4;
    static final byte opERROR = 5;
	
	public Client() {
		super("Client");
		
		try //create DatagramSocket
		{
			socket = new DatagramSocket();
			
		}//end try
		catch(SocketException socketException)
		{
			socketException.printStackTrace();
			System.exit(1);
		}//end catch
	}
	
	public void sendRRQ() 
	{
		int j = 0;
		int k = 0;
		data[0] = 0;
		data[1] = 1;
		
		
		byte[] fileBytes = stringToByte(fName);
		byte[] modeBytes = stringToByte(mode);
		
		for(int i = 2; i < data.length; i++)
		{
			//fills data[] up until end of string, including the termination byte
			if(j < fName.length() + 1)
			{
				
			data[i] = fileBytes[j];
			j++;
			
			}
			//if fileName is filled do this
			else 
			{
			data[i] = 0; // byte that takes the place after filename and mode
						//fills to end of packet
			
			while(k < mode.length()) 
				{
				data[i] = modeBytes[k];
				
				k++;
				i++;
				}//end of while
			
			}//end of else
			
			
		}//end of for loop
		/*
		try {
			//placeholder packet to send
			sendPacket = new DatagramPacket(data, data.length, InetAddress.getLocalHost(), 5000);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//end of catch
		*/
	}
	
	public void sendWRQ() 
	{
		int j = 0;
		int k = 0;
		data[0] = 0;
		data[1] = 2;
		
		
		byte[] fileBytes = stringToByte(fName);
		byte[] modeBytes = stringToByte(mode);
		
		for(int i = 2; i < data.length; i++)
		{
			//fills data[] up until end of string, including the termination byte
			if(j < fName.length() + 1)
			{
				
			data[i] = fileBytes[j];
			j++;
			
			}
			//if fileName is filled do this
			else 
			{
			data[i] = 0; // byte that takes the place after filename and mode
						//fills to end of packet
			
			while(k < mode.length()) 
				{
				data[i] = modeBytes[k];
				
				k++;
				i++;
				}//end of while
			
			}//end of else
		}//end of for
		
		/*
		try {
			//placeholder packet to send
			sendPacket = new DatagramPacket(data, data.length, InetAddress.getLocalHost(), 5000);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//end of catch
		*/
		
	}//end of method
	
	public void sendDATA() 
	{
		
	}//end of method
	
	public void sendError() 
	{
		
	}//end of method
	
	public void receive()
	{
		
	}//end of method
	
	//gets a string and converts to a byte array
	public byte[] stringToByte(String chara)
	{
		char[] letters = chara.toCharArray();//creates an array of characters  
		byte[] conversion = new byte[letters.length + 1]; 
		
		for(int i = 0; i < letters.length; i++)
		{
			if(i == letters.length)
			{
				conversion[i] = 0; //indicates end of file name
			}
			
			else
			{
			conversion[i] = (byte)letters[i]; //converts character into byte
			}
			
		}//end of for loop
		
		return conversion;
		
		
	}//end do of stringToByte
	
	private boolean isLastPacket(DatagramPacket datagramPacket) 
	{
		if(datagramPacket.getLength() < 512)
			return true;
		else
			return false;
	}//end of isLastPacket
	
	private ByteArrayOutputStream receiveFile() throws IOException
	{
		ByteArrayOutputStream byteOutOS = new ByteArrayOutputStream();
		int block = 1;
		do {
			System.out.println("TFTP Packet Count: " + block);
			block++;
			incoming = new DatagramPacket(data,
					data.length, inetAddress,
					socket.getLocalPort());
			
			//receiving the packet from server
			socket.receive(incoming);
			
			//getting first 4 characters from packet
			byte[] opCode = RRQopcode;
			
			if(opCode[1] == opERROR) {
				reportError();
			} else if(opCode[1] == opDATA) {
				byte[] bNum = { (byte) 2, (byte) 3};
				DataOutputStream stream = new DataOutputStream(byteOutOS);
				stream.write(incoming.getData(), 4, incoming.getLength() - 4);
				
				sendAck(bNum);
			}
			
			
		} while(!isLastPacket(incoming));
		return byteOutOS;
	}//end of recieveFile
	
	private void reportError()
	{
		String errorCode = new String(data, 3, 1);
		String errorText = new String(data, 4, incoming.getLength() - 4);
		System.err.println("Error: "+ errorCode + " " + errorText);
	}//end of reportError
	
	private void sendAck(byte[] bNum) {
		byte[] ACK = {0, opACK, bNum[0], bNum[1] };
		
		//Gets new port and sends the ack
		DatagramPacket ack = new DatagramPacket(ACK, ACK.length, incoming.getPort());
		
		try {
			socket.send(ack);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}//end of sendAck
	
}
